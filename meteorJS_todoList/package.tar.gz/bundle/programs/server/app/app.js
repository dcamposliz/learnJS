var require = meteorInstall({"imports":{"api":{"tasks.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// imports/api/tasks.js                                                    //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
module.export({Tasks:function(){return Tasks}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                           // 2
                                                                           // 3
                                                                           //
var Tasks = new Mongo.Collection('tasks');                                 // 5
                                                                           //
if (Meteor.isServer) {                                                     // 7
  // this code only runs on the server                                     //
  Meteor.publish('tasks', function tasksPublication() {                    // 9
    return Tasks.find({                                                    // 10
      $or: [{ 'private': { $ne: true } }, { owner: this.userId }]          // 11
    });                                                                    // 10
  });                                                                      // 16
}                                                                          // 17
                                                                           //
Meteor.methods({                                                           // 19
  'tasks.insert': function tasksInsert(text) {                             // 20
    check(text, String);                                                   // 21
                                                                           //
    // make sure the user is logged in before inserting a tasks            //
    if (!this.userId) {                                                    // 24
      throw new Meteor.Error('not-authorized');                            // 25
    }                                                                      // 26
                                                                           //
    Tasks.insert({                                                         // 28
      text: text,                                                          // 29
      createdAt: new Date(),                                               // 30
      owner: this.userId,                                                  // 31
      username: Meteor.users.findOne(this.userId).username                 // 32
    });                                                                    // 28
  },                                                                       // 34
  'tasks.remove': function tasksRemove(taskId) {                           // 35
    check(taskId, String);                                                 // 36
                                                                           //
    var task = Tasks.findOne(taskId);                                      // 38
    if (task['private'] && task.owner !== this.userId) {                   // 39
      // if the task is private, make sure only the owner can delete it    //
      throw new Meteor.Error('not-authorized');                            // 41
    }                                                                      // 42
                                                                           //
    Tasks.remove(taskId);                                                  // 44
  },                                                                       // 45
  'tasks.setChecked': function tasksSetChecked(taskId, setChecked) {       // 46
    check(taskId, String);                                                 // 47
    check(setChecked, Boolean);                                            // 48
                                                                           //
    var task = Tasks.findOne(taskId);                                      // 50
    if (task['private'] && task.owner !== this.userId) {                   // 51
      // if the task is private, make sure only the owner can check it off
      throw new Meteor.Error('not-authorized');                            // 53
    }                                                                      // 54
                                                                           //
    Tasks.update(taskId, { $set: { checked: setChecked } });               // 56
  },                                                                       // 57
  'tasks.setPrivate': function tasksSetPrivate(taskId, setToPrivate) {     // 58
    check(taskId, String);                                                 // 59
    check(setToPrivate, Boolean);                                          // 60
                                                                           //
    var task = Tasks.findOne(taskId);                                      // 62
                                                                           //
    // make sure only the task owner can make a task private               //
    if (task.owner !== this.userId) {                                      // 65
      throw new Meteor.Error('not-authorized');                            // 66
    }                                                                      // 67
                                                                           //
    Tasks.update(taskId, { $set: { 'private': setToPrivate } });           // 69
  }                                                                        // 70
});                                                                        // 19
/////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/tasks.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// server/main.js                                                          //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
module.import('../imports/api/tasks.js');                                  // 1
                                                                           //
// import { Meteor } from 'meteor/meteor';                                 //
                                                                           //
// Meteor.startup(() => {                                                  //
// code to run on server at startup                                        //
// });                                                                     //
/////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
